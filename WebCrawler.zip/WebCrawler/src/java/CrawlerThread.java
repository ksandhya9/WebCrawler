
import java.io.PrintWriter;
import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sandhyaranikairam
 */
public class CrawlerThread extends Thread{
    int depth;
    URL url;
    PrintWriter out = null;
     private final Set<URL> links;
     Set<URL> last_visited;
     HashSet setofurls = null;
    public CrawlerThread(URL url, int depth, PrintWriter out,Set<URL> last_visited) {
        this.links = new HashSet<>();
        this.url = url;
        this.depth = depth;
        this.out = out;
        this.last_visited = last_visited;
    }

    CrawlerThread(HashSet s, int depth, PrintWriter out, Set<URL> last_visited) {
        this.links = new HashSet<>();
        this.setofurls = s;
        this.depth = depth;
        this.out = out;
        this.last_visited = last_visited;
    }

    @Override
    public void run() {
        if(this.setofurls!=null){
            try {
                crawl(this.setofurls,1);
            } catch (InterruptedException ex) {
                Logger.getLogger(CrawlerThread.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else{
        try {
                synchronized(this.last_visited){
                    this.last_visited.addAll(initURLS(this.url));
                 }
                synchronized(this.out){
                if(this.out!=null){
                    this.out.print("data: "+ this.url+"\n\n");
                }
                }
            crawl(initURLS(this.url),1);
        
        } catch (InterruptedException ex) {
            Logger.getLogger(CrawlerThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        }
    }
    
    private Set<URL> initURLS(final URL startURL) {
        return Collections.singleton(startURL);
    }

    
    private void crawl(Set<URL> urls,int level) throws InterruptedException {
        urls.removeAll(this.links);
        if(!urls.isEmpty() && level<=depth-1) {
            synchronized(this.last_visited){
             this.last_visited.removeAll(urls);
            }
            final Set<URL> newURLS = new HashSet<>();
            try {
                this.links.addAll(urls);
                for(final URL url : urls) {
                    System.out.println(" connected to : " + url);
                    final Document document = Jsoup.connect(url.toString()).get();
                    final Elements linksOnPage = document.select("a[href]");
                    for(final Element element : linksOnPage) {
                        final String urlText = element.attr("abs:href");
                        final URL discoveredURL = new URL(urlText);
                        newURLS.add(discoveredURL);
                    }
                }
                 synchronized(this.last_visited){
                    this.last_visited.addAll(newURLS);
                 }
            } catch(final Exception | Error ignored) {
            }
            synchronized(this.out){
                if(this.out!=null && !newURLS.isEmpty()){
                    this.out.print("data: "+ newURLS+"\n\n");
                }
            }
            //this.sleep((long)2000); 
            if(level<depth-1){
                crawl(newURLS,level++);
            }
        } 
    }

}
