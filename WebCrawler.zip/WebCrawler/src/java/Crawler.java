/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sandhyaranikairam
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class Crawler {
    int depth;
    //private final Set<URL> links;
    public final int Max_Threads = 50;
    URL url;
    PrintWriter out = null;
    String lastVisitedUrls;
    public Set<URL> last_visited =new HashSet<>();
 

    public Crawler(URL url1, PrintWriter out,int depth) {
        //this.links = url1;
        this.url = url1; //To change body of generated methods, choose Tools | Templates.
        this.out = out;
        this.depth = depth;
    }
       public Crawler(String urls, PrintWriter out,int depth) {
        //this.links = url1;
        this.lastVisitedUrls = urls; //To change body of generated methods, choose Tools | Templates.
        this.out = out;
        this.depth = depth;
    }
       public ArrayList<HashSet> createSets() throws MalformedURLException{
           String lastUrls[] = this.lastVisitedUrls.split(",");
           ArrayList<HashSet> urlsSetList = new ArrayList<HashSet>();
           int n = lastUrls.length/5;
           int mod = lastUrls.length%5;
           int i = 0;
               for(i = 0;i<lastUrls.length-mod;i+=n){
                   HashSet<URL> urlSet = new HashSet<URL>();
                   for(int k=0;k<n;k++){
                      URL url = new URL(lastUrls[i+k]); 
                      urlSet.add(url);
                   }  
                   urlsSetList.add(urlSet);
                }
              HashSet<URL> urlSet = new HashSet<URL>();
                  for(int k =i;k<lastUrls.length;k++ ){
                      URL url = new URL(lastUrls[k]);
                      urlSet.add(url);
              }
              if(!urlSet.isEmpty()){
                      urlsSetList.add(urlSet);
              }    
           return urlsSetList;
       }
    public void resumethreadCreation() throws MalformedURLException, IOException, InterruptedException {
        ArrayList<HashSet> urlsets = createSets();
        ArrayList<Thread> threads = new ArrayList<Thread>();
        for(HashSet s: urlsets){
            CrawlerThread t = new CrawlerThread(s,this.depth,out,last_visited);
             t.start();
             threads.add(t);
        }
        for (Thread thread:threads){
              thread.join();
          }
    }
    public Set<URL> threadCreation() throws MalformedURLException, IOException, InterruptedException {
        final Document document = Jsoup.connect(url.toString()).get();
        final Elements linksOnPage = document.select("a[href]");
        final Set<URL> newURLS = new HashSet<>();
        int count = 0;
        CrawlerThread t = null;
        ArrayList<Thread> threads = new ArrayList<Thread>();
            for(final Element element : linksOnPage) {
                if(count ==20)
                    break;
                final String urlText = element.attr("abs:href");
                final URL discoveredURL = new URL(urlText);
                newURLS.add(discoveredURL);
                t = new CrawlerThread(discoveredURL,this.depth,out,last_visited);                                                                                                                                                                                             
                t.start();
                threads.add(t);
                count++;
            }
            for (Thread thread:threads){
                thread.join();
            }
        System.out.println("was executed");
        return newURLS;
    }
}
