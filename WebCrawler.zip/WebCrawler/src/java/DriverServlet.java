/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author sandhyaranikairam
 */
public class DriverServlet extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, MalformedURLException {
               response.setContentType("text/event-stream");
               response.setCharacterEncoding("UTF-8"); 
               PrintWriter out = null;
               
        System.out.println("hi");
//        while(true){
        try {
            out = response.getWriter();
            String depthS = request.getParameter("depth");
           int depth=1;
           depth = Integer.parseInt(depthS);   
           String isresume =  request.getParameter("resume");
           if(isresume!=null&& "true".equalsIgnoreCase(isresume)){
               String lastvisitedurls= request.getParameter("urls");
               Crawler crawl = new Crawler(lastvisitedurls,out,depth+1);
               crawl.resumethreadCreation();
               System.out.print(lastvisitedurls);
               ArrayList<URL> notCrawled = new ArrayList<URL>();
               int len =0; 
               for(URL url:crawl.last_visited){
                   if(len++==5){
                       break;
                   }
                   notCrawled.add(url);
                           
               }
                out.print("data: cookie"+ notCrawled.toString()+"\n\n");
                out.print("data: "+"done"+"\n\n");
               //resume(lastvisitedurls,depth,out);
           }else{
           String url = request.getParameter("url");
           URL url1 = new URL(url);
 
           Crawler crawl = new Crawler(url1,out,depth);
                   try {
                       Set<URL> urls = crawl.threadCreation();
                      // Cookie lastVistedUrls = new Cookie("lastVistedUrls",crawl.last_visited.toString());
                            ArrayList<URL> notCrawled = new ArrayList<URL>();
                         int len =0;
                         for(URL url2:crawl.last_visited){
                          if(len++==5){
                              break;
                         }
                            notCrawled.add(url2);                  
               }
                       out.print("data: cookie"+ notCrawled.toString()+"\n\n");
                       out.print("data: "+"done"+"\n\n");
                   } catch (InterruptedException ex) {
                       Logger.getLogger(DriverServlet.class.getName()).log(Level.SEVERE, null, ex);
                   }
            
            
        } 
        }catch (Exception ex) {
            Logger.getLogger(DriverServlet.class.getName()).log(Level.SEVERE, null, ex);
            out.close();
          //  break;
        }
          
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void resume(Set<URL> lastvisitedurls, int depth, PrintWriter out) {
        System.out.println("testing"+lastvisitedurls);//To change body of generated methods, choose Tools | Templates.
    }

}
